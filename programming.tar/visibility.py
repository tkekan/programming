



if __name__ == "__main__":
    if False:
        visibility = []

    visibility.append(10)
    print visibility
