



def canreach(nums):
    


# you start with k = 1 and every time you can take k, k-1 or k + 1 steps starting
# from index 0
nums = [3,5,6,8,12,17]

print canreach(nums)



