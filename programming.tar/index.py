


for index in range(1,10):
    j = index * index
    while j < 10:
        print j
        j = j + index

