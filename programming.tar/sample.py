



def todo():

    time = 0
    def more():
        local time
        time += 1

    more()

todo()
