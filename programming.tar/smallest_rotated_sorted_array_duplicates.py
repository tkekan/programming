


def search(nums):
    low = 0
    high = len(nums) - 1

    while low <= high:
        



nums = [3,3,1,3]
