

def part(nums):
    low = 0
    high = len(nums) -1
    lsum = nums[low]

nums = [1, 5, 11, 5]
print part(nums)
