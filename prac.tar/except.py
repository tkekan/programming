import traceback
import sys

def bow():
    try:
        big  = 10
        raise NameError
    except Exception as e:
        print "Caught here " + (repr(e))
        val = traceback.format_exc()
        raise IOError("Raising from bow")
    #finally:
    #    raise IOError("Rasing finally")


try:
    ret = bow()
    #print "return value: %s" %ret
except Exception as e:
    print "Now in main" + (repr(e)) + str(e.message)
