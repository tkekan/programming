


def func( num):
    if num == 4:
        return 2
    else: 
        return 2 * func ( num + 1)

print func(2)

