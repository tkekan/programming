

def maximum_area(l):
    for i in range(0, len(l)):
        left = i
        


hist = [6, 2, 5, 4, 5, 1, 6]
maximum_area(hist)
