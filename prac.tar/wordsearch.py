class Solution(object):
    def dfs(self, board, word, r, c, index):
        if r < 0 or r == len(board) or c < 0 or c == len(board[0]) or board[r][c] == '#':
            return False
        
        if index == len(word) -1 and word[index] == board[r][c]:
            return True
        
        if word[index]!= board[r][c]:
            return False
        
        char = board[r][c] 
        board[r][c] = '#'
        
        if (self.dfs(board,word,r+1,c,index+1) or
            self.dfs(board,word,r-1,c,index+1) or
            self.dfs(board,word,r,c+1,index+1) or
            self.dfs(board,word,r,c-1,index+1)):
            return True

        board[r][c] = char
        return False
        
    def exist(self, board, word):
        """
        :type board: List[List[str]]
        :type word: str
        :rtype: bool
        """
        found = False
        for r in range(0,len(board)):
            for c in range(0,len(board[0])):
                if word[0] == board[r][c]:
                    found = self.dfs(board,word,r,c,0)
                    if found:
                        return True
        return False

s = Solution()
board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]]
board = [["C","A","A"],["A","A","A"],["B","C","D"]]
word = "AABCDZ"
print s.exist(board,word)
