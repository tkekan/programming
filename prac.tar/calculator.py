
def add(a,b):
    return a+b
    
def sub(a,b):
    return a-b
    
def mult(a,b):
    return a * b

def div(a,b):
    try:
        return float(a / b)
    except Exception as e:
        print e
    
    
function_map = {'+' : add,
                '-' : sub, '*' : mult, '/' :div }


def calculator_input(data):
    data = list(data)
    stack = []
    result = 0
    operator = None
    for index in range(0,len(data)):
        if data[index] not in ['+','-','*', '/']:
            #print "appending", data[index]
            stack.append(data[index])
            if operator != None and len(stack) > 1:
                num1 = stack.pop()
                num2 = stack.pop()
                if '/' or '*' in data[index:] and operator in ['+','-']:
                    temp = str(num1) + str(operator) + str(num2)
                    stack.append(temp)
                    print stack
                    continue
                result = function_map[operator](int(num2),int(num1))
                stack.append(result)
                #print result
        else:
            operator = data[index]
            #print operator
    print result

input_s = "3+4/2"         
calculator_input(input_s)
