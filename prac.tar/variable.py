


def newl(l):
	if len(l):
		print "found in this newl: ", m



if __name__ == "__main__":	
	l1 = [1,2,3]
	m = l1[0]
	newl([1,2,3])
	print "ouside: ", m

