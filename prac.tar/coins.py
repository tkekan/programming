



def numOfWays(val , coins):
    for i in range(0, len(coins)):
        while sum != val:
            sum = sum + coins[i]

coins = [1,2,4,10]
numOfWays(50, coins)
